package com.cams.notification.product;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class NotificationBkProductApplication {
    public static void main(String[] args) {
        SpringApplication.run(NotificationBkProductApplication.class, args);
    }
}
