package com.cams.notification.product.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class OrderNotificationRequest {

    @NotBlank(message = "customerName is required")
    @Size(min = 2, max = 100, message = "customerName must be 2-100 characters")
    private String customerName;

    @NotBlank(message = "email is required")
    @Email(message = "email is invalid")
    @Pattern(regexp = "^\\S+@\\S+\\.\\S+$", message = "email must not contain spaces")
    private String email;

    @NotBlank(message = "orderId is required")
    @Pattern(regexp = "^[A-Za-z0-9-]{3,40}$",
             message = "orderId must be 3-40 chars (letters, digits, hyphen)")
    private String orderId;

    @NotBlank(message = "productName is required")
    @Size(min = 2, max = 255, message = "productName must be 2-255 characters")
    private String productName;

    @Min(value = 1, message = "quantity must be at least 1")
    private int quantity;

    @NotNull(message = "price is required")
    @DecimalMin(value = "0.01", inclusive = true, message = "price must be >= 0.01")
    private BigDecimal price;

    // ---- getters/setters ----
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
}
