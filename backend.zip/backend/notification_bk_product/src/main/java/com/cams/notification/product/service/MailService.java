package com.cams.notification.product.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String username;

    // Optional; if blank we’ll fall back to spring.mail.username
    @Value("${app.mail.from:}")
    private String fromProp;

    public MailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    private static String clean(String s) {
        if (s == null) return null;
        // trim spaces, remove CR/LF, strip leading/trailing quotes
        String x = s.trim().replaceAll("[\\r\\n]", "");
        x = x.replaceAll("^['\\\"]|['\\\"]$", "");
        return x;
    }

    private String resolveFrom() {
        String f = clean(fromProp);
        return (f == null || f.isBlank()) ? clean(username) : f;
    }

    public void sendPlainText(String toRaw, String subject, String body) {
        String from = resolveFrom();
        String to   = clean(toRaw);

        // simple strict-ish validation so JavaMail won’t choke later
        if (from == null || !from.matches("^\\S+@\\S+\\.\\S+$")) {
            throw new IllegalArgumentException("Invalid 'from' email. Use a plain address like user@gmail.com");
        }
        if (to == null || !to.matches("^\\S+@\\S+\\.\\S+$")) {
            throw new IllegalArgumentException("Invalid 'to' email. Use a plain address like user@gmail.com");
        }

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom(from);            // String (not InternetAddress)
        msg.setTo(to);                // String (not InternetAddress)
        msg.setSubject(subject);
        msg.setText(body);

        mailSender.send(msg);
    }
}
