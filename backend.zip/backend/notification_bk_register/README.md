# notification_bk_register

Spring Boot microservice to send a **registration success email** after validating input.

- **Port:** 8090
- **Endpoint:** `POST /api/register`
- **Static test page:** open `http://localhost:8090/register.html`

## Request body

```json
{
  "username": "john_doe",
  "phoneNumber": "9876543210",
  "email": "user@example.com",
  "password": "Strong@123",
  "confirmPassword": "Strong@123"
}
```

## Validation
- `username`: 3–20 chars, letters/digits/underscore
- `phoneNumber`: 10–15 digits
- `email`: valid email
- `password`: ≥8 chars, at least one uppercase, one lowercase, one digit, one special
- `confirmPassword`: must equal `password`

## Email config (Gmail App Password)
Set these env vars before running:
```
export MAIL_USERNAME="yourgmail@gmail.com"
export MAIL_PASSWORD="your_16_char_app_password"  # generated under Google Account → Security → App passwords
export MAIL_FROM="yourgmail@gmail.com"            # optional; if omitted, uses MAIL_USERNAME
```

## Run (STS / Maven)
- Import as Maven project in STS/IntelliJ
- Or CLI: `mvn spring-boot:run`

## Postman
Import the Postman collection from `postman/notifications.postman_collection.json` and hit **Register (8090)**.


## Database (MySQL)
This service stores records in MySQL using Spring JDBC.
Set environment variables (or edit `application.properties`):

```
export DB_URL='jdbc:mysql://localhost:3306/cams_notifications?createDatabaseIfNotExist=true&allowPublicKeyRetrieval=true&useSSL=false'
export DB_USERNAME='root'
export DB_PASSWORD='password'
```

- A `schema.sql` is executed on startup to create tables if they don't exist.
- Passwords are stored as BCrypt hashes (registration service).
