package com.cams.notification.register;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificationBkRegisterApplication {
    public static void main(String[] args) {
        SpringApplication.run(NotificationBkRegisterApplication.class, args);
    }
}
