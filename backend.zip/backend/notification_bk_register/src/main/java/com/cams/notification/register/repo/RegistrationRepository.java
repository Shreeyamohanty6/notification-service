package com.cams.notification.register.repo;

import com.cams.notification.register.model.Registration;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public class RegistrationRepository {

    private final JdbcTemplate jdbc;
    private final SimpleJdbcInsert insert;

    public RegistrationRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
        this.insert = new SimpleJdbcInsert(jdbc)
                .withTableName("registrations")
                .usingGeneratedKeyColumns("id");
    }

    public long save(Registration r) {
        SqlParameterSource params = new MapSqlParameterSource(Map.of(
                "username", r.getUsername(),
                "phone_number", r.getPhoneNumber(),
                "email", r.getEmail(),
                "password_hash", r.getPasswordHash()
        ));
        Number key = insert.executeAndReturnKey(params);
        return key.longValue();
    }
}
