package com.cams.notification.register.controller;

import com.cams.notification.register.dto.ApiResponse;
import com.cams.notification.register.dto.RegisterRequest;
import com.cams.notification.register.model.Registration;
import com.cams.notification.register.repo.RegistrationRepository;
import com.cams.notification.register.service.MailService;
import com.cams.notification.register.util.PasswordHasher;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class RegisterController {

    private final MailService mailService;
    private final RegistrationRepository registrationRepository;
    private final PasswordHasher passwordHasher;

    public RegisterController(MailService mailService, RegistrationRepository registrationRepository, PasswordHasher passwordHasher) {
        this.mailService = mailService;
        this.registrationRepository = registrationRepository;
        this.passwordHasher = passwordHasher;
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse> register(@Valid @RequestBody RegisterRequest req) {
        String hashed = passwordHasher.hash(req.getPassword());
        Registration entity = new Registration(req.getUsername(), req.getPhoneNumber(), req.getEmail(), hashed);
        registrationRepository.save(entity);

        String subject = "Registration Successful";
        String body = String.format(
                "Hi %s,%n%nYour account has been registered successfully.%n%nUsername: %s%nPhone: %s%n%nCheers,%nCAMS Team",
                req.getUsername(), req.getUsername(), req.getPhoneNumber()
        );
        mailService.sendPlainText(req.getEmail(), subject, body);
        return ResponseEntity.ok(new ApiResponse(true, "Saved & email sent to " + req.getEmail()));
    }

    @GetMapping("/health")
    public ResponseEntity<ApiResponse> health() {
        return ResponseEntity.ok(new ApiResponse(true, "OK"));
    }
}
