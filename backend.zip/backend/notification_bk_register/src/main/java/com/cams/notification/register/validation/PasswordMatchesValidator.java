package com.cams.notification.register.validation;

import java.lang.reflect.Field;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, Object> {

    private String passwordField;
    private String confirmPasswordField;

    @Override
    public void initialize(PasswordMatches constraintAnnotation) {
        this.passwordField = constraintAnnotation.password();
        this.confirmPasswordField = constraintAnnotation.confirmPassword();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        try {
            Field pwd = value.getClass().getDeclaredField(passwordField);
            Field cpw = value.getClass().getDeclaredField(confirmPasswordField);
            pwd.setAccessible(true);
            cpw.setAccessible(true);
            Object p = pwd.get(value);
            Object c = cpw.get(value);
            if (p == null || c == null) return false;
            return p.equals(c);
        } catch (Exception e) {
            return false;
        }
    }
}
