package com.cams.notification.product;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class NotificationSbsProductApplication {
  public static void main(String[] args) {
    SpringApplication.run(NotificationSbsProductApplication.class, args);
  }
}
